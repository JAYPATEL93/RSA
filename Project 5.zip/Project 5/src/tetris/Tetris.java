//
// Group: Chirag Patel, Opin Patel, and Kena Patel
// CS 342: Project 5
//

package tetris;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class Tetris extends Applet {
 public Tetris() {
 }
 
 private final static int DELAY = 1000;
 private final static byte ROWS = 20;
 private final static byte COLUMNS = 10;
 private final static int EMPTY = -1;
 private final static int REMOVED_ROWS_PER_LEVEL = 10;

 Tetromino tetromino = Tetrominoes.getInstance();
 private final Color TETROMINO_COLORS[] = tetromino.getTetrominoColor();
 private final static Color BACKGROUND_GAME_COLORS[] = {
  // defined colors
  new Color(0x99FFCC),
  new Color(0x0099CC), 
  new Color(0xFFDAB9), 
  new Color(0x9966CC), 
  new Color(0xFFC0CB), 
  new Color(0xFF99CC), 
 };

 
 private static boolean tmp_game_grid[][] = new boolean[4][4]; // scratch space
 private static Random random = new Random();
 private final static Color BACKGROUND_SCORE_COLOR = new Color(0x9966CC);   
 private final boolean TETROMINO_PIECE[][][] = Tetrominoes.getTetrominoes();
 
 private static class TetrisGameLabel extends Label {
  private final static Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 16);
  private TetrisGameLabel(String text) {
   super(text);
   setFont(LABEL_FONT);
  }
  private void addValue(int val) {
   setText(Integer.toString((Integer.parseInt(getText())) + val ));
  }
 }
  
 //instance data
 protected int grid[][] = new int[ROWS][COLUMNS];
 protected int next_piece_grid[][] = new int[4][4];
 protected int num_rows_deleted = 0;
 protected int old_rows_deleted = 0;
 protected Timer timer;
 protected TetrisPiece cur_piece;
 protected TetrisPiece next_piece = randomPiece();
 protected PlayingArea game_grid = new PlayingArea(grid, true);
 protected PlayingArea next_piece_canvas = new PlayingArea(next_piece_grid, false); 
 protected TetrisGameLabel rows_deleted_label = new TetrisGameLabel("0");
 protected TetrisGameLabel level_label = new TetrisGameLabel("1");
 protected TetrisGameLabel score_label = new TetrisGameLabel("0");
 final Button start_newgame_butt = new TetrisGameButton("Start");
 
 final Button game_pause_resume_butt = new TetrisGameButton("Pause");
 final Button about_butt = new TetrisGameButton("About");
 final Button help_butt = new TetrisGameButton("Help");
 final Button quit_butt = new TetrisGameButton("Quit");
 
 // INNER CLASSES
 private class TetrisGameButton extends Button {
  public TetrisGameButton(String label) {
   super(label);
  }
  public Dimension getPreferredSize() {
   return new Dimension(120, super.getPreferredSize().height);
  }
  
 }
   
 private class TetrisPiece {
  private boolean tetris_squares[][];
  private int tetromino_type;
  private Point tetromino_position = new Point(3, -4); // -4 to start above top row
  
  public void setX(int newx) {
   tetromino_position.x = newx; 
  }
  public void setY(int newy) {
   tetromino_position.y = newy; 
  }
  public int getX() {
   return tetromino_position.x;
  }
  public int getY() {
   return tetromino_position.y; 
  }
  public void setPosition(int newx, int newy) {
   setX(newx);
   setY(newy); 
  }
  
  public TetrisPiece(int type) {
   this.tetromino_type = type;
   this.tetris_squares = new boolean[4][4];
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     this.tetris_squares[i][j] = TETROMINO_PIECE[type][i][j];
  }
  
  
  
  public boolean canPaste() {
   for(int i=0; i<4; i++) {
    for(int j=0; j<4; j++) {
     int to_x = j + tetromino_position.x;
     int to_y = i + tetromino_position.y;
     if(tetris_squares[i][j]) { 
      if(0 > to_x || to_x >= COLUMNS 
       || to_y >= ROWS)
      {
       return false;
      }
      if(to_y >= 0 && grid[to_y][to_x] != EMPTY)
       return false;
     }
    }
   }
   return true;
  }
  
  public boolean canStepDown() {
   synchronized(timer) {
    cut();
    tetromino_position.y++;
    boolean OK = canPaste();
    tetromino_position.y--;
    paste();
    return OK;
   }
  }
  
  public void stepDown() {
   tetromino_position.y++;
  }
  
  public void cut() {
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     if(tetris_squares[i][j] && tetromino_position.y+i>=0)
      grid[tetromino_position.y + i][tetromino_position.x + j] = EMPTY;
  }
  
   //Paste the color info of this piece into the given grid
  public void paste(int into[][]) {
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     if(tetris_squares[i][j] && tetromino_position.y+i>=0)
      into[tetromino_position.y + i][tetromino_position.x + j] = tetromino_type;
  }
  // No argument version assumes pasting into main game grid
  public void paste() {
   paste(grid);
  }
  
  public void rotate() {
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     tmp_game_grid[i][j] = tetris_squares[i][j];
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     tetris_squares[j][i] = tmp_game_grid[i][3-j];
  }
  
  public void rotateBack() {
   for(int i=0; i<4; i++)
    for(int j=0; j<4; j++)
     tetris_squares[i][j] = tmp_game_grid[i][j];
  }
  
 
  public boolean isTetrominoTotallyOnGrid() {
   for(int i=0; i<4; i++) {
    if(tetromino_position.y + i >= 0)
     return true;
    //everything from here down is on grid
    for(int j=0; j<4; j++)
     if(tetris_squares[i][j])
      return false;
   }
   System.err.println("TetrisPiece.isTotallyOnGrid internal error");
   return false;
  }
 }
 

 private class Timer extends Thread {
  private long m_delay;
  private boolean m_paused = true;
  private boolean m_fast = false;
  private ActionListener m_cb;
  public Timer(long delay, ActionListener cb) { 
   setDelay(delay);
   m_cb = cb;
  }
  public void setPaused(boolean pause) { 
   m_paused = pause;
   if(m_paused) {
   }
   else {
    synchronized(this) {
     this.notify();
    }
   }
  }
  public boolean isPaused() {
   return m_paused; 
  }
  
  public boolean isRunning() {
   return !m_paused; 
  }
  
  public void setDelay(long delay) {
   m_delay = delay; 
  }
  
  public void setFast(boolean fast) {
   m_fast = fast;
   if(m_fast) {
    try {
     this.checkAccess();
     this.interrupt(); // no exception, so OK to interrupt
    } catch(SecurityException se) {}
   }
  }
  public boolean isFast() { return m_fast; }
  public void faster() {
   m_delay = (int)(m_delay * .9); //increase the speed exponentially in reverse
  }
  public void run() {
   while(true) {
    try { 
     sleep(m_fast ? 30 : m_delay); 
    } catch (Exception e) {}
    if(m_paused) {
     try {
      synchronized(this) {
       this.wait();
      }
     } catch(InterruptedException ie) {}
    }
    synchronized(this) {
     m_cb.actionPerformed(null);
    }
   }
  }
 }

 private class PlayingArea extends DoubleBufferedCanvas {
  private int grid[][];
  private boolean paint_background;
  public PlayingArea(int[][] grid, boolean do_background) {
   this.grid = grid;
   paint_background = do_background;
   clear();
  }
 
  private void clear() {
   for(int i=0; i<grid.length; i++)
    for(int j=0; j<grid[0].length; j++)
     grid[i][j] = EMPTY;
  }  
  public Dimension getPreferredSize() {
   return new Dimension(grid[0].length * 30, grid.length * 30);
  }
  public void paint(Graphics g) {
   g = this.startPaint(g); // returned g paints into offscreen image
   int width = this.getSize().width;
   int height = this.getSize().height;   
   double panel_aspect_ratio = (double)width/height;
   g.clearRect(0, 0, width, height);
   int cell_size, xstart, ystart;
   double grid_aspect_ratio = (double)grid[0].length/grid.length;
   if(panel_aspect_ratio > grid_aspect_ratio) { 
    
    cell_size = (int)((double)height/grid.length + 0.5);
    xstart = (int)(width/2 - (grid[0].length/2.0 * cell_size + 0.5));
    ystart = 0;
   }
   else { 
    // extra vertical space
    cell_size = (int)((double)width/grid[0].length + 0.5);
    xstart = 0;
    ystart = (int)(height/2 - (grid.length/2.0 * cell_size + 0.5));
   }
   if(paint_background) {
    g.setColor(BACKGROUND_GAME_COLORS[(num_rows_deleted / REMOVED_ROWS_PER_LEVEL) % BACKGROUND_GAME_COLORS.length]);
    g.fillRect(xstart, ystart, COLUMNS*cell_size, ROWS*cell_size);
   }
   for(int i=0; i<grid.length; i++) {
    for(int j=0; j<grid[0].length; j++) {
     if(grid[i][j] != EMPTY) {
      g.setColor(TETROMINO_COLORS[grid[i][j]]);
      int x = xstart + j*cell_size;
      int y = ystart + i*cell_size;
      g.fill3DRect(x, y, cell_size, cell_size, true);
     }
    }
   }
   this.endPaint(); // paints accumulated image in one shot
  }
 } // end class GridCanvas
 
 // INSTANCE METHODS
 private TetrisPiece randomPiece() {
  int rand = Math.abs(random.nextInt());
  return new TetrisPiece(rand % (TETROMINO_COLORS.length));
 }
 
 private void installNewPiece() {
  next_piece_canvas.clear();
  cur_piece = next_piece;
  cur_piece.setPosition(3, -4); //-4 to start above top of grid
  if(cur_piece.canPaste()) {
   next_piece = randomPiece();
   next_piece.setPosition(0, 0);
   next_piece.paste(next_piece_grid);
   next_piece_canvas.repaint();
  }
  else
   gameOver();
 }
 
 private void gameOver() {
  System.out.println("Game Over!");
  timer.setPaused(true);
  game_pause_resume_butt.setEnabled(false);
  int score = Integer.parseInt(score_label.getText());
 }
 
 private boolean rowIsFull(int row) {
  for(int i=0; i<COLUMNS; i++)
   if(grid[row][i] == EMPTY)
    return false;
  return true;
 }
 
 private int countFullRows() {
  int n_full_rows = 0;
  for(int i=0; i<ROWS; i++)
   if(rowIsFull(i))
    n_full_rows++;
  return n_full_rows;
 } 
 
 private void removeRow(int row) {
  for(int j=0; j<COLUMNS; j++)
   grid[row][j] = EMPTY;
  for(int i=row; i>0; i--) {
   for(int j=0; j<COLUMNS; j++) {
    grid[i][j] = grid[i-1][j];
   }
  }
 }
 
 private void removeFullRows() {
  int n_full = countFullRows();
  if(n_full == 0)
  return;
  if(num_rows_deleted / REMOVED_ROWS_PER_LEVEL != (num_rows_deleted+n_full) / REMOVED_ROWS_PER_LEVEL) {
   timer.faster();
   if(n_full / REMOVED_ROWS_PER_LEVEL + 1<=24)
   {
    level_label.addValue(n_full / REMOVED_ROWS_PER_LEVEL + 1);
   }
   level_label.repaint();
  }
  rows_deleted_label.addValue(n_full);
  old_rows_deleted = num_rows_deleted;
  num_rows_deleted += n_full;
  for(int i=ROWS-1; i>=0; i--)
   while(rowIsFull(i))
    removeRow(i);
  game_grid.repaint();
 }
 
 public void start() {
  timer = new Timer(DELAY, new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    synchronized(timer) {
     if(cur_piece.canStepDown()) {
      cur_piece.cut();
      cur_piece.stepDown();
      cur_piece.paste();
     }
     else { // it hit something
      timer.setFast(false);
      if( ! cur_piece.isTetrominoTotallyOnGrid())
       gameOver();
      else {
       removeFullRows();
       if(num_rows_deleted-old_rows_deleted==1)
       {
        score_label.addValue((int)40);
        old_rows_deleted = num_rows_deleted;
       }
       else if(num_rows_deleted-old_rows_deleted==2)
       {
        score_label.addValue((int)100);
        old_rows_deleted = num_rows_deleted;
       }
       else if(num_rows_deleted-old_rows_deleted==3)
       {
        score_label.addValue((int)300);
        old_rows_deleted = num_rows_deleted;
       }
       else if(num_rows_deleted-old_rows_deleted>=4)
       {
        score_label.addValue((int)1200);
        old_rows_deleted = num_rows_deleted;
       }
       installNewPiece();
      }
     }
    }
    game_grid.repaint();
   }
  });
  timer.start(); // pauses immediately
 }
 
 public void stop() {
  pauseGame();
  synchronized(timer){
   timer.stop();
  }
  timer = null;
 }
 
 private void startGame() {
  timer.setDelay(DELAY);
  timer.setPaused(false);
  start_newgame_butt.setLabel("Start New Game");
  game_pause_resume_butt.setEnabled(true); // stays enabled from here on
  game_pause_resume_butt.setLabel("Pause");
  game_pause_resume_butt.validate();
 }
 
 private void newGame() {
  game_grid.clear();
  installNewPiece();
  num_rows_deleted = 0;
  rows_deleted_label.setText("0");
  level_label.setText("1");
  score_label.setText("0");
  startGame();
 }
 
 private void pauseGame() {
  timer.setPaused(true);
  game_pause_resume_butt.setLabel("Resume");
 }
 
 private void resumeGame() {
  timer.setPaused(false);
  game_pause_resume_butt.setLabel("Pause");
 }
 
 
 public void init() {
  installNewPiece();

  game_pause_resume_butt.setEnabled(false);
  start_newgame_butt.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    if(start_newgame_butt.getLabel().equals("Start"))
     startGame();
    else
     newGame();
   }
  });  
  game_pause_resume_butt.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    if(game_pause_resume_butt.getLabel().equals("Pause"))
     pauseGame();
    else
     resumeGame();
   }
  });
  
  quit_butt.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    System.exit(0);
   }
  });
  
  
  
  help_butt.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    
     UIManager UI=new UIManager();
     UI.put("OptionPane.background", new Color(0x99FFCC));
     UI.put("Panel.background", new Color(0x99FFCC));
     
    String help = "1) Press start button to start the game \n"
      + "2) Press pause button to pause the game \n"
      + "3) Press Up arrow key to rotate the tetromino\n"
      + "4) Press Down arrow key to 'Soft Drop'\n"
      + "5) Press Right and Left arrow keys to change the position\n"
      + "6) Press Quit button to exit the game\n";
    
    JOptionPane.showMessageDialog(null, help ,"Help", JOptionPane.INFORMATION_MESSAGE);
   }
  });
  
  about_butt.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent ae) {
    UIManager UI=new UIManager();
     UI.put("OptionPane.background", new Color(0x99FFCC));
     UI.put("Panel.background", new Color(0x99FFCC));
    JOptionPane.showMessageDialog(null, "Created by:\nChirag Patel\n" +
                                                    "Opin Patel\n"   +
                                                    "Kena Patel\n"   +
                                         "Purpose: The 5th programming assignment for CS 342.","About", JOptionPane.INFORMATION_MESSAGE); 
   }
  });
  
  //create key listener for rotating, moving left, moving right
  KeyListener key_listener = new KeyAdapter() {
   public void keyPressed(KeyEvent e) {
    if(timer.isPaused()) //don't do anything if game is paused
     return;
    if (e.getKeyCode() == 37 || e.getKeyCode() == 39) { //left or right arrow pressed
     int dir = e.getKeyCode() == 37 ? -1 : 1;
     synchronized(timer) {
      cur_piece.cut();
      cur_piece.setX(cur_piece.getX() + dir); // try to move
      if( ! cur_piece.canPaste())
       cur_piece.setX(cur_piece.getX() - dir); // undo move
      cur_piece.paste();
     }
     game_grid.repaint();
    }
    else if (e.getKeyCode() == 38) { //rotate
     synchronized(timer) {
      cur_piece.cut();
      cur_piece.rotate();
      if( ! cur_piece.canPaste())
       cur_piece.rotateBack();
      cur_piece.paste();
     }
     game_grid.repaint();
    }
    if (e.getKeyCode() == 40) { //down arrow pressed; drop piece
     timer.setFast(true);
    }
   }
  };
  
  // add the key listener to all components that might get focus
  // so that it'll work regardless of which has focus
  start_newgame_butt.addKeyListener(key_listener);
  game_pause_resume_butt.addKeyListener(key_listener);
  about_butt.addKeyListener(key_listener);
  help_butt.addKeyListener(key_listener);
  quit_butt.addKeyListener(key_listener);
  
  start_newgame_butt.setBackground(new Color(0x99FFCC));
  game_pause_resume_butt.setBackground(new Color(0x99FFCC));
  about_butt.setBackground(new Color(0x99FFCC));
  help_butt.setBackground(new Color(0x99FFCC));
  quit_butt.setBackground(new Color(0x99FFCC));
  
  start_newgame_butt.setForeground(new Color(0x9966CC));
  game_pause_resume_butt.setForeground(new Color(0x9966CC));
  about_butt.setForeground(new Color(0x9966CC));
  help_butt.setForeground(new Color(0x9966CC));
  quit_butt.setForeground(new Color(0x9966CC));
  
  start_newgame_butt.setFont(new Font("Segoe UI", Font.BOLD, 12));
  game_pause_resume_butt.setFont(new Font("Segoe UI", Font.BOLD, 12));
  about_butt.setFont(new Font("Segoe UI", Font.BOLD, 12));
  help_butt.setFont(new Font("Segoe UI", Font.BOLD, 12));
  quit_butt.setFont(new Font("Segoe UI", Font.BOLD, 12));
  
  Panel right_panel = new Panel(new GridLayout(3, 1)); 
  right_panel.setBackground(BACKGROUND_SCORE_COLOR);
  
  Panel control_panel = new Panel();
  control_panel.add(start_newgame_butt);
  control_panel.add(game_pause_resume_butt);
  control_panel.add(about_butt);
  control_panel.add(help_butt);
  
  control_panel.setBackground(BACKGROUND_SCORE_COLOR);
  right_panel.add(control_panel);
  
  Panel tmp = new Panel(new BorderLayout());
  tmp.add("North", new TetrisGameLabel("    Next Piece:"));
  tmp.add("Center", next_piece_canvas);
  tmp.setBackground(BACKGROUND_SCORE_COLOR);
  right_panel.add(tmp);
  
  Panel stats_panel = new Panel(new GridLayout(1, 2));
  stats_panel.add(new TetrisGameLabel("    Deleted: "));
  stats_panel.add(rows_deleted_label);
  Panel level_panel = new Panel(new GridLayout(1, 2));
  level_panel.add(new TetrisGameLabel("    Level: "));
  level_panel.add(level_label);
  Panel score_panel = new Panel(new GridLayout(1, 2));
  score_panel.add(new TetrisGameLabel("    Score: "));
  score_panel.add(score_label);
  
  Panel t = new Panel(new GridLayout(4,1));
  t.add(stats_panel);
  t.add(level_panel);
  t.add(score_panel);
  t.add(quit_butt);
  
  tmp = new Panel(new BorderLayout());
  tmp.setBackground(BACKGROUND_SCORE_COLOR);
  tmp.add("Center", t);
  right_panel.add(tmp);
  
  // finaly, add all the main panels to the applet panel
  this.setLayout(new GridLayout(1, 2));
  this.add(game_grid);
  this.add(right_panel);
  this.setBackground(BACKGROUND_SCORE_COLOR);
  this.validate();
 }

 
 public static void main(String[] args) {

  Frame frame = new Frame("Tetris");
  Tetris tetris = new Tetris();
  frame.add(tetris);
  tetris.init();
  tetris.start();

  frame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  frame.setSize(489, 441);
  frame.setResizable(false);
  frame.setVisible(true);
 }
} // end class Tetris


class DoubleBufferedCanvas extends Canvas {
 private Image mActiveOffscreenImage = null;
 private Dimension mOffscreenSize = new Dimension(-1,-1);
 private Graphics mActiveOffscreenGraphics = null;
 private Graphics mSystemGraphics = null;
 
 DoubleBufferedCanvas() {
 }

 public void update(Graphics g) {
  paint(g);
 }

 public Graphics startPaint (Graphics sysgraph) {
  mSystemGraphics = sysgraph;
  // Initialize if this is the first pass or the size has changed
  Dimension d = getSize();
  if ((mActiveOffscreenImage == null) ||
   (d.width != mOffscreenSize.width) ||
   (d.height != mOffscreenSize.height)) 
  {
   mActiveOffscreenImage = createImage(d.width, d.height);
   mActiveOffscreenGraphics = mActiveOffscreenImage.getGraphics();
   mOffscreenSize = d;
   mActiveOffscreenGraphics.setFont(getFont());
  }
  return mActiveOffscreenGraphics;
 }
 
 public void endPaint () {
  mSystemGraphics.drawImage(mActiveOffscreenImage, 0, 0, null);
 }
}

