//
// Group: Chirag Patel, Opin Patel, and Kena Patel
// CS 342: Project 5
//

package tetris;

import java.awt.Color;

public class Tetromino {
 
 private final Color TETROMINO_COLORS[] = {
  new Color(0xFF00FF),
  new Color(0xDC143C), 
  new Color(0x00CED1), 
  new Color(0xFFD700), 
  new Color(0x32CD32), 
  new Color(0x008080), 
  new Color(0xFFA500), 
 };
 
 public Color [] getTetrominoColor()
 {
  return TETROMINO_COLORS;
 }
 
 
}

class Tetrominoes extends Tetromino
{
 private static Tetrominoes instance = new Tetrominoes();

    private Tetrominoes(){}

    public static Tetrominoes getInstance(){
       return instance;
    }
    
 private final static boolean TETROMINO_BITS[][][] = {
  {
   {false, true, false, false},
   {false, true, false, false},
   {false, true, false, false},
   {false, true, false, false},
  },
  {
   {false, false, false, false},
   {false, true, true, false},
   {false, true, false, false},
   {false, true, false, false},
  },
  {
   {false, false, false, false},
   {false, true, false, false},
   {false, true, false, false},
   {false, true, true, false},
  },
  {
   {false, false, false, false},
   {false, true, false, false},
   {false, true, true, false},
   {false, false, true, false},
  },
  {
   {false, false, false, false},
   {false, false, true, false},
   {false, true, true, false},
   {false, true, false, false},
  },
  {
   {false, false, false, false},
   {false, true, false, false},
   {false, true, true, false},
   {false, true, false, false},
  },
  {
   {false, false, false, false},
   {false, false, false, false},
   {false, true, true, false},
   {false, true, true, false},
  },
 };
 
 public static boolean[][][] getTetrominoes()
 {
  return TETROMINO_BITS;
 }
}
